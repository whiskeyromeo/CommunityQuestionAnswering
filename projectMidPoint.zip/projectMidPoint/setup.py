import nltk

nltk.download('book')